import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from './Button';
import { SITE_NAME } from '../constants';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-black/80 backdrop-blur-md py-4 border-b border-white/10' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo Section - Matching Image Structure: APEXLABS (White/Yellow) + by Achzod */}
        <a 
          href="https://www.achzodcoaching.com/" 
          target="_blank" 
          rel="noopener noreferrer" 
          className="flex flex-col leading-none group cursor-pointer"
        >
          <span className="text-2xl font-black tracking-tighter text-white uppercase">
            APEX<span className="text-neuro-accent">LABS</span>
          </span>
          <span className="text-sm font-medium text-gray-400 tracking-wide group-hover:text-white transition-colors">
            by Achzod
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-300">
          <Link to="/offers" className="hover:text-neuro-accent transition-colors">Offres</Link>
          <Link to="/vision" className="hover:text-neuro-accent transition-colors">Vision</Link>
          <Button variant="outline" onClick={() => navigate('/join-waitlist')} className="!px-6 !py-2 text-xs hover:!border-neuro-accent hover:text-neuro-accent">
            S'inscrire
          </Button>
        </nav>
      </div>
    </header>
  );
};