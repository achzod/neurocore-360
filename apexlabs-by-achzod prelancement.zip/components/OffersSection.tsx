import React from 'react';
import { useNavigate } from 'react-router-dom';
import { OFFERS } from '../constants';
import { OfferCard } from './OfferCard';

export const OffersSection: React.FC = () => {
  const navigate = useNavigate();

  const handleSelect = () => {
    navigate('/join-waitlist');
  };

  return (
    <section id="offers" className="bg-black py-24 relative">
      <div className="container mx-auto px-6">
        <div className="mb-20 text-center max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">Mes Offres</h2>
          <p className="text-gray-400">
            Des solutions adaptées à chaque niveau d'exigence. Choisissez votre voie vers l'excellence cognitive.
          </p>
        </div>

        <div className="flex flex-col">
          {OFFERS.map((offer) => (
            <OfferCard key={offer.id} offer={offer} onSelect={handleSelect} />
          ))}
        </div>
      </div>
    </section>
  );
};