import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './Button';
import { TAGLINE } from '../constants';

export const Hero: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');

  const handleQuickJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if(!email) return;
    setStatus('loading');
    setTimeout(() => {
      setStatus('success');
      setEmail('');
    }, 1500);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Video */}
      <div className="absolute inset-0 z-0">
        <video 
          autoPlay 
          loop 
          muted 
          playsInline 
          className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-screen scale-110 animate-[pulse-slow_8s_infinite]"
        >
            <source src="https://cdn.speedsize.com/3f711f28-1488-44dc-b013-5e43284ac4b0/https://public-web-assets.uh-static.com/web_v2/m1/space.mp4" type="video/mp4" />
        </video>
        {/* Overlay to ensure text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-black/50 to-black/95" />
        
        {/* Animated Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-20" />
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center flex flex-col items-center perspective-1000">
        
        {/* Badge */}
        <div className="animate-fade-in-down delay-100 mb-8 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md text-xs font-medium tracking-[0.2em] text-gray-300 uppercase shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(252,221,0,0.3)] hover:border-neuro-accent/50 transition-all duration-500">
          <span className="w-1.5 h-1.5 rounded-full bg-neuro-accent animate-[pulse_1s_infinite]"></span>
          COACHING & PERFORMANCE
        </div>
        
        {/* Main Title - APEXLABS BY ACHZOD */}
        <div className="animate-fade-in-up delay-200 mb-8 cursor-default flex flex-col items-center">
            {/* APEXLABS - White & Yellow */}
            <h1 className="text-5xl md:text-7xl lg:text-9xl font-black tracking-tighter leading-[0.9] mb-2">
                <span className="block text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] transition-transform duration-700 hover:scale-[1.02]">
                    APEX<span className="text-neuro-accent">LABS</span>
                </span>
            </h1>
            
            {/* Subtitle - Clean "by Achzod", reduced spacing, no glitch */}
            <span className="text-xl md:text-3xl font-light tracking-[0.2em] text-gray-400">
                by Achzod
            </span>
        </div>

        {/* Tagline */}
        <p className="animate-fade-in-up delay-300 max-w-2xl text-lg md:text-xl text-gray-300 mb-10 leading-relaxed font-light tracking-wide mix-blend-difference">
          {TAGLINE} <br/>
          <span className="text-gray-500">
            La convergence de la biologie et de la technologie.
          </span>
        </p>

        {/* Early Access Input */}
        <div className="animate-fade-in-up delay-500 w-full max-w-md mb-12 relative group">
            {/* Glowing border effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-neuro-accent via-white/20 to-neuro-accent opacity-30 blur-lg rounded-full group-hover:opacity-60 transition-opacity duration-1000"></div>
            
            {status === 'success' ? (
                <div className="bg-green-500/20 backdrop-blur-xl border border-green-500/50 text-green-400 px-8 py-4 rounded-full text-sm font-bold tracking-wider animate-pulse border-glow-green">
                    INSCRIPTION VALIDÉE
                </div>
            ) : (
                <form onSubmit={handleQuickJoin} className="relative flex p-1 bg-black/40 backdrop-blur-xl border border-white/20 rounded-full transition-all duration-300 focus-within:border-neuro-accent/50 focus-within:shadow-[0_0_30px_rgba(252,221,0,0.1)]">
                    <input 
                        type="email" 
                        placeholder="Entrez votre email..." 
                        className="flex-1 bg-transparent border-none text-white px-6 focus:ring-0 placeholder-gray-500 outline-none text-sm"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <button type="submit" className="bg-white text-black px-6 py-2.5 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-neuro-accent hover:text-black transition-colors shadow-lg">
                        {status === 'loading' ? '...' : 'Rejoindre'}
                    </button>
                </form>
            )}
        </div>

        {/* Secondary Buttons */}
        <div className="animate-fade-in-up delay-700 flex flex-col sm:flex-row gap-5 w-full justify-center opacity-80 hover:opacity-100 transition-opacity">
          <Button onClick={() => navigate('/offers')} variant="outline" className="text-xs hover:!border-neuro-accent hover:text-neuro-accent">
            Découvrir les offres
          </Button>
        </div>

      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50 animate-bounce cursor-pointer" onClick={() => navigate('/offers')}>
        <span className="text-[10px] uppercase tracking-[0.3em] text-gray-500">Explore</span>
        <svg className="w-4 h-4 text-neuro-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg>
      </div>
    </section>
  );
};