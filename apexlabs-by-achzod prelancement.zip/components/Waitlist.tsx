import React, { useState } from 'react';
import { Button } from './Button';

export const Waitlist: React.FC = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setStatus('loading');
    
    // Simulate API call
    setTimeout(() => {
      console.log('Registered:', email);
      setStatus('success');
      setEmail('');
    }, 1500);
  };

  return (
    <section id="join-waitlist" className="py-32 relative bg-neutral-900 overflow-hidden">
      {/* Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto bg-black/50 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-16 text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-white tracking-tight">
            ACCÈS ANTICIPÉ
          </h2>
          <p className="text-gray-400 text-lg mb-10 max-w-xl mx-auto">
            Rejoignez la liste d'attente exclusive pour Neurocore 360. Les places pour la phase bêta sont limitées.
          </p>

          {status === 'success' ? (
            <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-8 animate-pulse-slow">
              <p className="text-green-400 text-xl font-medium">Inscription confirmée.</p>
              <p className="text-gray-400 mt-2">Nous vous contacterons très prochainement.</p>
              <button 
                onClick={() => setStatus('idle')}
                className="mt-6 text-sm text-gray-500 hover:text-white underline"
              >
                Inscrire un autre email
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4 max-w-lg mx-auto">
              <input
                type="email"
                placeholder="votre@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-white/5 border border-white/10 rounded-full px-6 py-4 text-white placeholder-gray-600 focus:outline-none focus:border-white/40 focus:bg-white/10 transition-all"
                required
              />
              <Button type="submit" disabled={status === 'loading'}>
                {status === 'loading' ? 'Traitement...' : "S'inscrire"}
              </Button>
            </form>
          )}

          <p className="mt-8 text-xs text-gray-600 uppercase tracking-widest">
            Sécurité des données garantie • Désabonnement à tout moment
          </p>
        </div>
      </div>
    </section>
  );
};