import React, { useRef, useEffect, useState } from 'react';
import { Offer } from '../types';
import { Button } from './Button';

interface OfferCardProps {
  offer: Offer;
  onSelect: () => void;
}

export const OfferCard: React.FC<OfferCardProps> = ({ offer, onSelect }) => {
  const { id, title, subtitle, description, features, price, imageUrl, reverse } = offer;
  const cardRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  // Intersection Observer for Scroll Reveal
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 } 
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => {
      if (cardRef.current) observer.unobserve(cardRef.current);
    };
  }, []);

  const isBloodAnalysis = id === 'blood-analysis';
  
  // UNIFIED YELLOW THEME for everything
  const accentColorClass = 'text-neuro-accent';
  const glowColorClass = 'bg-neuro-accent/20';
  const borderColorClass = 'border-neuro-accent/20 group-hover:border-neuro-accent/50';
  const shadowClass = 'shadow-[0_0_50px_rgba(252,221,0,0.15)] group-hover:shadow-[0_0_80px_rgba(252,221,0,0.25)]';
  const dotColorClass = 'bg-neuro-accent shadow-[0_0_10px_#FCDD00]';

  const revealClass = isVisible 
    ? 'opacity-100 translate-y-0 filter-none' 
    : 'opacity-0 translate-y-20 blur-sm';

  return (
    <div 
      ref={cardRef}
      className={`py-24 border-b border-white/5 last:border-0 group transition-all duration-1000 ease-out ${revealClass}`}
    >
      <div className={`flex flex-col ${reverse ? 'lg:flex-row-reverse' : 'lg:flex-row'} items-center gap-12 lg:gap-24`}>
        
        {/* Image Side with HUD/Tech Overlay */}
        <div className="w-full lg:w-1/2 relative perspective-1000">
          <div className={`relative aspect-[4/3] overflow-hidden rounded-xl bg-neutral-900 border transition-all duration-500 ${borderColorClass} ${shadowClass}`}>
            
            {/* Scan Line Animation - Horizontal for ECG (Blood), Vertical for others */}
            <div className={`absolute inset-0 z-30 pointer-events-none opacity-20 group-hover:opacity-100 transition-opacity duration-700`}>
                {isBloodAnalysis ? (
                  // Horizontal Heartbeat/ECG Scan - Yellow
                  <div className="absolute top-0 left-0 h-full w-[2px] bg-neuro-accent/50 shadow-[0_0_20px_#FCDD00] animate-[scan-horizontal_2s_infinite_linear]" />
                ) : (
                  // Vertical Scan
                  <div className="absolute top-0 left-0 w-full h-[10%] bg-gradient-to-b from-transparent via-neuro-accent/20 to-transparent animate-[scan_3s_infinite_linear]" />
                )}
            </div>

            {/* HUD Elements Overlay */}
            <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-white/30 z-20 rounded-tl-lg group-hover:border-white/80 transition-colors" />
            <div className="absolute top-4 right-4 w-8 h-8 border-r-2 border-t-2 border-white/30 z-20 rounded-tr-lg group-hover:border-white/80 transition-colors" />
            <div className="absolute bottom-4 left-4 w-8 h-8 border-l-2 border-b-2 border-white/30 z-20 rounded-bl-lg group-hover:border-white/80 transition-colors" />
            <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-white/30 z-20 rounded-br-lg group-hover:border-white/80 transition-colors" />

            {/* Floating Label */}
            <div className={`absolute top-8 left-8 z-20 backdrop-blur-md px-3 py-1 border rounded text-[10px] tracking-widest uppercase font-bold shadow-lg bg-black/60 border-neuro-accent/30 text-neuro-accent`}>
               {isBloodAnalysis ? 'RHYTHM ANALYSIS // ACTIVE' : 'SYSTEM ONLINE'}
            </div>

             {/* Overlay Gradient for Noir effect */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80 z-10" />
            
            {/* Main Image */}
            <img 
              src={imageUrl} 
              alt={title} 
              className={`
                w-full h-full object-cover transition-all duration-700 transform 
                ${isBloodAnalysis 
                  ? 'opacity-80 group-hover:opacity-100 scale-100 hover:scale-105 contrast-125 brightness-110 saturate-150 hue-rotate-[180deg] sepia-[1]' 
                  : 'opacity-70 group-hover:opacity-100 grayscale group-hover:grayscale-0 group-hover:scale-110 group-hover:rotate-1'
                }
              `}
            />
          </div>
          
          {/* Decorative glowing orb behind */}
          <div className={`absolute -inset-4 ${glowColorClass} blur-[60px] rounded-full -z-10 opacity-20 group-hover:opacity-50 transition-opacity duration-700 animate-pulse`} />
        </div>

        {/* Content Side */}
        <div className="w-full lg:w-1/2 space-y-8">
          <div>
            <div className={`text-xs font-bold uppercase tracking-[0.2em] mb-4 flex items-center gap-3 ${accentColorClass}`}>
              <span className={`w-2 h-2 rounded-full animate-pulse ${dotColorClass}`}></span>
              {subtitle}
            </div>
            
            <h3 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-400 transition-all duration-300">
              {title}
            </h3>
            
            <p className="text-gray-400 text-lg leading-relaxed border-l border-white/10 pl-6 group-hover:border-white/40 transition-colors duration-500">
              {description}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((feature, idx) => (
              <div 
                key={idx} 
                className={`flex items-center gap-3 text-gray-300 bg-white/5 p-3 rounded-lg border border-white/5 hover:border-neuro-accent/30 hover:bg-white/10 transition-all duration-300 hover:translate-x-1`}
                style={{ transitionDelay: `${idx * 100}ms` }}
              >
                <div className={`w-1.5 h-1.5 rounded-full bg-neuro-accent`} />
                <span className="text-sm font-medium tracking-wide">{feature}</span>
              </div>
            ))}
          </div>

          <div className="pt-6">
            <Button variant="secondary" onClick={onSelect} className={`w-full sm:w-auto !border-white/20 hover:!border-neuro-accent/50 hover:shadow-[0_0_30px_rgba(252,221,0,0.3)]`}>
              Sélectionner le protocole
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};