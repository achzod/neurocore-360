import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { OffersSection } from './components/OffersSection';
import { Waitlist } from './components/Waitlist';
import { Footer } from './components/Footer';

// Component to handle scrolling based on URL hash path (e.g., #/offers -> scroll to #offers)
const ScrollToHash = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    // Remove the leading slash to get the ID (e.g., "/offers" -> "offers")
    const elementId = pathname.replace(/^\//, '');
    
    if (elementId) {
      const element = document.getElementById(elementId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-white selection:text-black">
      <ScrollToHash />
      <Header />
      <main>
        <Hero />
        <OffersSection />
        <Waitlist />
      </main>
      <Footer />
    </div>
  );
}

export default App;